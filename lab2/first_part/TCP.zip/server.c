/*
 * Protocoale de comunicatii
 * Laborator 7 - TCP
 * Echo Server
 * server.c
 */

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>

#define BUFLEN 1500

int main(int argc, char *argv[])
{
    int sockfd = 0, newsfd = 0, iter = 0, check = 0;
    char buf[BUFLEN];
    struct sockaddr_in serv_addr; 

    if(argc != 3)
    {
        printf("\n Usage: %s <ip> <port>\n", argv[0]);
        return 1;
    }

    // deschidere socket
    sockfd = socket(PF_INET, SOCK_STREAM, 0);

    // completare informatii despre adresa serverului
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(atoi(argv[2]));
    inet_aton("127.0.0.1", &(serv_addr.sin_addr));

    // legare proprietati de socket
    check = bind(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
    
    if (check < 0) {
        printf("[SERVER] Nu s-a facut bind\n");
        return -1;
    }

    // ascultare de conexiuni
    check = listen(sockfd, 3);

    if (check < 0) {
        printf("[SERVER] Nu s-a facut listen\n");
        return -1;
    }

    socklen_t size = sizeof(struct sockaddr_in);

    while (1) {
        
        // acceptarea unei conexiuni, primirea datelor, trimiterea raspunsului
        newsfd = accept(sockfd, (struct sockaddr*) &serv_addr, &size);

        if (newsfd < 0) {
            printf("[SERVER] Nu s-a facut accept\n");
            return -1;
        }
        
        while (++iter) {
        
            int nr = recv(newsfd, buf, BUFLEN, 0);
            printf("[SERVER] Primit ");
            for (int i = 0; i < nr; i++)
                printf("%c", buf[i]);
            printf("\n");

            if (iter % 2)
                send(newsfd, "YES", strlen("YES"), 0);
            else
                send(newsfd, "NO", strlen("NO"), 0);

            if (strncmp(buf, "QUIT", 4) == 0)
                shutdown(newsfd, SHUT_RDWR);
            
            if (strncmp(buf, "STOP", 4) == 0)
                break;
        }
    }

    // inchidere socket(i)
    close(sockfd);
    close(newsfd);

    return 0;
}
